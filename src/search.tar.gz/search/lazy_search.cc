#include "lazy_search.h"

#include "g_evaluator.h"
#include "heuristic.h"
#include "successor_generator.h"
#include "sum_evaluator.h"
#include "weighted_evaluator.h"
#include "plugin.h"

#include <algorithm>
#include <limits>
#include <math.h>

static const int DEFAULT_LAZY_BOOST = 1000;

LazySearch::LazySearch(const Options &opts)
    : SearchEngine(opts),
      open_list(opts.get<OpenList<OpenListEntryLazy> *>("open")),
      reopen_closed_nodes(opts.get<bool>("reopen_closed")),
      succ_mode(pref_first),
      current_state(g_initial_state()),
      current_predecessor_id(StateID::no_state),
      current_operator(NULL),
      current_g(0),
      current_real_g(0)
{

    if(opts.getIsAnyTime() == true)
        m_is_anytime = true;
    else 
        m_is_anytime = false;

}

LazySearch::~LazySearch() {
}

void LazySearch::set_pref_operator_heuristics(
    vector<Heuristic *> &heur) {
    preferred_operator_heuristics = heur;
}

void LazySearch::initialize() {
    //TODO children classes should output which kind of search
    cout << "Conducting lazy best first search, (real) bound = " << bound << endl;

    assert(open_list != NULL);
    set<Heuristic *> hset;
    open_list->get_involved_heuristics(hset);

    for (set<Heuristic *>::iterator it = hset.begin(); it != hset.end(); it++) {
        estimate_heuristics.push_back(*it);
        search_progress.add_heuristic(*it);
    }

    // add heuristics that are used for preferred operators (in case they are
    // not also used in the open list)
    hset.insert(preferred_operator_heuristics.begin(),
                preferred_operator_heuristics.end());

    for (set<Heuristic *>::iterator it = hset.begin(); it != hset.end(); it++) {
        heuristics.push_back(*it);
    }
    assert(!heuristics.empty());

    f_incumbent = 0;
    solution_found = false;
    m_is_H_updated = false;
    m_isRpac_lower_bound_satisfied = false;
    m_is_open_based_pac_cond_sutisfied = false;
    m_Initial_H = -1;
    
}

void LazySearch::get_successor_operators(vector<const Operator *> &ops) {
    vector<const Operator *> all_operators;
    vector<const Operator *> preferred_operators;

    g_successor_generator->generate_applicable_ops(
        current_state, all_operators);

    for (int i = 0; i < preferred_operator_heuristics.size(); i++) {
        Heuristic *heur = preferred_operator_heuristics[i];
        if (!heur->is_dead_end())
            heur->get_preferred_operators(preferred_operators);
    }

    if (succ_mode == pref_first) {
        for (int i = 0; i < preferred_operators.size(); i++) {
            if (!preferred_operators[i]->is_marked()) {
                ops.push_back(preferred_operators[i]);
                preferred_operators[i]->mark();
            }
        }

        for (int i = 0; i < all_operators.size(); i++)
            if (!all_operators[i]->is_marked())
                ops.push_back(all_operators[i]);
    } else {
        for (int i = 0; i < preferred_operators.size(); i++)
            if (!preferred_operators[i]->is_marked())
                preferred_operators[i]->mark();
        ops.swap(all_operators);
        if (succ_mode == shuffled)
            random_shuffle(ops.begin(), ops.end());
    }
}

void LazySearch::generate_successors() 
{

    // double error = 1 + m_pac_epsilon;
    // double prob = 0;
    // bool found = false;     

    vector<const Operator *> operators;
    get_successor_operators(operators);
    search_progress.inc_generated(operators.size());
    for (int i = 0; i < operators.size(); i++) 
    {
        int new_g = current_g + get_adjusted_cost(*operators[i]);
        int new_real_g = current_real_g + operators[i]->get_cost();
        bool is_preferred = operators[i]->is_marked();
        if (is_preferred)
        {
            operators[i]->unmark();
        }
        if (new_real_g < bound)
        {
            open_list->evaluate(new_g, is_preferred);
            bool to_insert = false;
            if (m_is_anytime)
            {
                int f_val = open_list->evaluate_for_anytime(new_g, is_preferred);
               // cout << "evaluate_for_anytime: g = " << current_g << " c = " << get_adjusted_cost(*operators[i]) << " f = " << f_val << std::endl;
                if (f_val < f_incumbent || solution_found == false)
                    to_insert = true;

                //ration based + lower bound pac condition:
                // for every node generation we check for lower bound pac consition
                // f_val at this point is max(f_min) - because we check f value every step
                if(m_is_running_RPac_Lower_Bound)
                {
                    if(is_Ratio_PAC_Condition_Lower_Bound_satisfied(f_val))
                    {
                        // if during serch RPAC+LB is satisfied we set the member to true
                        // next time we check the member is when check RPAC in step()
                        m_isRpac_lower_bound_satisfied = true;
                        cout << "INFO: is_Ratio_PAC_Condition_Lower_Bound_satisfied? "<< 1 << std::endl;
                    }
                }

                else if(m_is_running_open_based_pac && f_incumbent > 0)
                {
                    // check if oben based pac condition is satisfied
                    // ----------------------------------------------
                    if(is_Ratio_PAC_Condition_Open_Based_satisfied())
                    {
                        cout<< "is_Ratio_PAC_Condition_Open_Based_satisfied ! ! ! = "  << endl;
                        cout<< "m_open_based_P_hat = " << m_open_based_P_hat << endl;

                        m_is_open_based_pac_cond_sutisfied = true;
                    }
                    else
                    {
                        //calculate m_open_based_P_hat:

                        int current_h = f_val - new_g;
                        cout << "new node added: new_g = [" << new_g << "]  new_real_g = [" << new_real_g << "] h = [" << current_h << "]" << endl;
                        increase_p_hat(new_g, current_h);
                    }


                }
            }
            else
            {
                to_insert = true;
            }
            
            if (to_insert)
            {
                open_list->insert(
                    make_pair(current_state.get_id(), operators[i]));
            }
        }
    } // for(...)

    if(m_is_running_open_based_pac && f_incumbent > 0)
    {
        // remove last node expanded from sum:
        //------------------------------------
        // cout << "OPEN BASED: remove last node expanded from sum:" << endl;

        int last_h = m_last_f_val - current_g;
        decrease_p_hat(current_g, last_h);
    }
    
}

int LazySearch::fetch_next_state() {
    if (open_list->empty()) {
        if (solution_found)
        {
            cout << "Completely explored state space -- but solution already found!" << endl;
            return SOLVED;
        }
        else
        {
            cout << "Completely explored state space -- no solution!" << endl;
        }
        return FAILED;
    }

    OpenListEntryLazy next = open_list->remove_min();

    current_predecessor_id = next.first;
    current_operator = next.second;
    State current_predecessor = g_state_registry->lookup_state(current_predecessor_id);
    assert(current_operator->is_applicable(current_predecessor));
    current_state = g_state_registry->get_successor_state(current_predecessor, *current_operator);

    SearchNode pred_node = search_space.get_node(current_predecessor);
    current_g = pred_node.get_g() + get_adjusted_cost(*current_operator);
    current_real_g = pred_node.get_real_g() + current_operator->get_cost();

    return IN_PROGRESS;
}

/*
----
\
 \                h*[   ]       1    [     U                ]
 /   Log(1 - Pr( ---| S | <  ------- |----------  - g_node  | ))  >= Log(1-delta)
/                 h [   ]     h_node [ 1+epsilon            ]
----
*/

/*
1 - init p-hat to 0
2 - go over all nodes in OPEN-LIST and calculate according to the above 
    pac condition 'p-hat'

*/
void LazySearch::calculate_p_hat()
{
    //typedef std::pair<StateID, const Operator *> OpenListEntryLazy;
    //typedef std::deque<OpenListEntryLazy> Bucket;
    // Entry = OpenListEntryLazy (in this case)

    m_open_based_P_hat = 0.0;


    std::vector<OpenListEntryLazy> openListStates;
    open_list->getFlattedOpenList(openListStates);
   
    std::vector<OpenListEntryLazy>::iterator it;
    for(it = openListStates.begin(); it != openListStates.end(); ++it)
    {
        // cout << "stateId = [" << it->first << "]" << endl;

        StateID sId = it->first;
        // const Operator * sOperator = it->second;

        State s = g_state_registry->lookup_state(sId);
        SearchNode sNode = search_space.get_node(s);
        
        int g = sNode.get_g(); 
        int h = heuristics[0]->get_h(s);

        cout << "calculate_p_hat: g = [" << g << "]" << endl;
        cout << "calculate_p_hat: h = [" << h << "]" << endl;
        
        increase_p_hat(g, h);
            
         
    }

}


/*
----
\
 \                h*[   ]       1    [     U                ]
 /   Log(1 - Pr( ---| S | <  ------- |----------  - g_node  | ))  >= Log(1-delta)
/                 h [   ]     h_node [ 1+epsilon            ]
----
*/

void LazySearch::increase_p_hat(int g, int h)
{
    // cout << "increase_p_hat:         g = [" << g << "]" << endl;
    // cout << "increase_p_hat:         h = [" << h << "]" << endl;
     

    double error = 1 + m_pac_epsilon;
    double prob = 0;
    // bool found = false;  
    if(h == 0)
        h = 1;

    double right = (1.0/h) *  ( (double(f_incumbent) / double(error))  - g );

    // cout << "right = (1.0/h<<[" << h << "]) *  ( (double(f_incumbent["<<f_incumbent<<"]) / double(error["<<error<< "]))  - g["<<g<<"] )" << endl;
    cout << "increase_p_hat   right = [" << right << "]" << endl;

    std::map<float, float>::const_iterator iter = m_ratio_to_statistics_for_pac.begin();
 
    while(iter != m_ratio_to_statistics_for_pac.end() && iter->first < right)
    {
        ++iter;
    }


        if(iter != m_ratio_to_statistics_for_pac.begin())
        {
            prob = (--iter)->second / 100;
            cout << " prob (--) = [" << prob << "]" << endl;
        }
        else
        {
            prob = iter->second / 100;
            cout << " prob (++) = [" << prob << "]" << endl;
        }


    double added_val = (log(1 - prob));
    // char str[128];
    // sprintf(str,"calc P hat: adding log(1 - prob[%f]) = [%f]",prob, added_val);
    // cout << str  << endl;

    m_open_based_P_hat += added_val; //log(1 - prob);
    cout << "calc P hat: m_open_based_P_hat = [" << m_open_based_P_hat << "]" << endl;
    
}

/*
----
\
 \                h*[   ]       1    [     U                ]
 /   Log(1 - Pr( ---| S | <  ------- |----------  - g_node  | ))  >= Log(1-delta)
/                 h [   ]     h_node [ 1+epsilon            ]
----
*/

void LazySearch::decrease_p_hat(int g, int h)
{
            double error = 1 + m_pac_epsilon;
    double prob = 0;
    // bool found = false;  


    double right = (1.0/h) *  ( (double(f_incumbent) / double(error))  - g );
    // cout << "right = (1.0/h<<["<<h<<"]) *  ( (double(f_incumbent["<<f_incumbent<<"]) / double(error["<<error<< "]))  - g["<<g<<"] )"<< endl;
    
    // cout << "decrease_p_hat   right = [" << right << "]" << endl;

    std::map<float, float>::const_iterator iter = m_ratio_to_statistics_for_pac.begin();
    // for (; iter != m_ratio_to_statistics_for_pac.end();++iter)
    // {
    //    if (iter->second > right)
    //    {
    //        found = true;
    //        break;
    //    }
    // } 
    while(iter != m_ratio_to_statistics_for_pac.end() && iter->first < right)
    {
        ++iter;
    }
    
    // if(found)
    // {
        if(iter != m_ratio_to_statistics_for_pac.begin())
        {
            prob = (--iter)->second / 100;
            // cout << " prob (--) = [" << prob << "]" << endl;
        }
        else
        {
            prob = iter->second / 100;
            // cout << " prob (++) = [" << prob << "]" << endl;
        }

        
    // }

    double added_val = (log(1 - prob));
    char str[128];
    sprintf(str,"calc P hat: decreasing log(1 - prob[%f]) = [%f]",prob, added_val);
    // cout << str  << endl;

    m_open_based_P_hat -= added_val; //log(1 - prob);
    // cout << "calc P hat: m_open_based_P_hat = [" << m_open_based_P_hat << "]" << endl;
}

int LazySearch::step() {
    // Invariants:
    // - current_state is the next state for which we want to compute the heuristic.
    // - current_predecessor is a permanent pointer to the predecessor of that state.
    // - current_operator is the operator which leads to current_state from predecessor.
    // - current_g is the g value of the current state according to the cost_type
    // - current_g is the g value of the current state (using real costs)

    SearchNode node = search_space.get_node(current_state);
    bool reopen = reopen_closed_nodes && (current_g < node.get_g()) && !node.is_dead_end() && !node.is_new();
    if (node.is_new() || reopen) {
        StateID dummy_id = current_predecessor_id;
        // HACK! HACK! we do this because SearchNode has no default/copy constructor
        if (dummy_id == StateID::no_state) {
            dummy_id = g_initial_state().get_id();
        }
        State parent_state = g_state_registry->lookup_state(dummy_id);
        SearchNode parent_node = search_space.get_node(parent_state);

        for (int i = 0; i < heuristics.size(); i++) {
            if (current_operator != NULL) {
                heuristics[i]->reach_state(parent_state, *current_operator, current_state);
            }
            heuristics[i]->evaluate(current_state);
        }
        search_progress.inc_evaluated_states();
        search_progress.inc_evaluations(heuristics.size());
        open_list->evaluate(current_g, false);
        if (!open_list->is_dead_end()) 
        {
            // We use the value of the first heuristic, because SearchSpace only
            // supported storing one heuristic value
            int h = heuristics[0]->get_value();
            if(!m_is_H_updated)
            {
                m_Initial_H = h;
                m_is_H_updated = true;
            }

            if(m_is_running_open_based_pac)
            {
                m_last_f_val = h + current_g;

            }
            
            if (reopen) 
            {
                node.reopen(parent_node, current_operator);
                search_progress.inc_reopened();
            } 

            else if (current_predecessor_id == StateID::no_state) 
            {
                node.open_initial(h);
                search_progress.get_initial_h_values();
            } 

            else 
            {
                node.open(h, parent_node, current_operator);
            }
           
            node.close();

            if (check_goal_and_set_plan(current_state))
            {
                if (!m_is_anytime)
                    return SOLVED;

                else
                {


                    // cout << "m_is_running_RPac_Lower_Bound = " << m_is_running_RPac_Lower_Bound << endl;
                    // cout << "m_is_running_open_based_pac = " << m_is_running_open_based_pac << endl;

                    //check if Ratio Based PAC condition is satisfied
                    if(  (!m_is_running_RPac_Lower_Bound) && (!m_is_running_open_based_pac)   )
                    {
                        cout << "*****************" << endl;
                        if( is_Ratio_PAC_Condition_satisfied() )
                        {
                                return SOLVED;
                        }
                    }

                    //check if this run is set to RPAB+LB
                    if( m_is_running_RPac_Lower_Bound)
                        // if it does - check if the condition is met
                        if(m_isRpac_lower_bound_satisfied)
                            return SOLVED;

                    if(m_is_running_open_based_pac)
                        if(m_is_open_based_pac_cond_sutisfied)
                        {
                            cout << "m_is_open_based_pac_cond_sutisfied = TRUE ----> solution found!" << endl;
                            return SOLVED;
                        }


                    if (!solution_found)
                    {
                        // cout <<"111111111111111111111111111111111111111111111111111111" << endl;
                        solution_found = true;
                        f_incumbent = current_g;
                        // cout << "first new f_incumbent = [" << f_incumbent <<"]" << endl;
                        //calculate p-hat for open based PAC condition:
                        // NOTE: p-hat calculation is performed after every new solution
                        calculate_p_hat(); 
                    }
                    else
                    {
                        if (current_g < f_incumbent)
                        {
                            // cout <<"222222222222222222222222222222222222222222222222222222222222" << endl;
                            f_incumbent = current_g;
                            // cout << "inprove new f_incumbent = [" << f_incumbent <<"]" << endl;
                            //calculate p-hat for open based PAC condition:
                            // NOTE: p-hat calculation is performed after every new solution
                            calculate_p_hat();
                        }

                    }


                }
            }
            if (search_progress.check_h_progress(current_g)) {
                reward_progress();
            }
            generate_successors();
            search_progress.inc_expanded();
        } else {
            node.mark_as_dead_end();
            search_progress.inc_dead_ends();
        }
    }
    return fetch_next_state();
}

void LazySearch::reward_progress() {
    // Boost the "preferred operator" open lists somewhat whenever
    open_list->boost_preferred();
}

void LazySearch::statistics() const {
    search_progress.print_statistics();
}

static SearchEngine *_parse(OptionParser &parser) {
    parser.document_synopsis("Lazy best first search", "");
    Plugin<OpenList<OpenListEntryLazy > >::register_open_lists();
    parser.add_option<OpenList<OpenListEntryLazy> *>("open", "open list");
    parser.add_option<bool>("reopen_closed",
                            "reopen closed nodes", "false");
    parser.add_list_option<Heuristic *>(
        "preferred",
        "use preferred operators of these heuristics", "[]");
    SearchEngine::add_options_to_parser(parser);
    Options opts = parser.parse();

    LazySearch *engine = 0;
    if (!parser.dry_run()) {
        engine = new LazySearch(opts);
        vector<Heuristic *> preferred_list =
            opts.get_list<Heuristic *>("preferred");
        engine->set_pref_operator_heuristics(preferred_list);
    }

    return engine;
}


static SearchEngine *_parse_greedy(OptionParser &parser) {
    parser.document_synopsis("Greedy search (lazy)", "");
    parser.document_note(
        "Open lists",
        "In most cases, lazy greedy best first search uses "
        "an alternation open list with one queue for each evaluator. "
        "If preferred operator heuristics are used, it adds an "
        "extra queue for each of these evaluators that includes "
        "only the nodes that are generated with a preferred operator. "
        "If only one evaluator and no preferred operator heuristic is used, "
        "the search does not use an alternation open list "
        "but a standard open list with only one queue.");
    parser.document_note("Equivalent statements using general lazy search",
         "\n```\n--heuristic h2=eval2\n"
         "--search lazy_greedy([eval1, h2], preferred=h2, boost=100)\n```\n"
         "is equivalent to\n"
         "```\n--heuristic h1=eval1 --heuristic h2=eval2\n"
         "--search lazy(alt([single(h1), single(h1, pref_only=true), single(h2),\n"
         "                  single(h2, pref_only=true)], boost=100),\n"
         "              preferred=h2)\n```\n"
         "------------------------------------------------------------\n"
         "```\n--search lazy_greedy([eval1, eval2], boost=100)\n```\n"
         "is equivalent to\n"
         "```\n--search lazy(alt([single(eval1), single(eval2)], boost=100))\n```\n"
         "------------------------------------------------------------\n"
         "```\n--heuristic h1=eval1\n--search lazy_greedy(h1, preferred=h1)\n```\n"
         "is equivalent to\n"
         "```\n--heuristic h1=eval1\n"
         "--search lazy(alt([single(h1), single(h1, pref_only=true)], boost=1000),\n"
         "              preferred=h1)\n```\n"
         "------------------------------------------------------------\n"
         "```\n--search lazy_greedy(eval1)\n```\n"
         "is equivalent to\n"
         "```\n--search lazy(single(eval1))\n```\n",
         true);

    parser.add_list_option<ScalarEvaluator *>("evals", "scalar evaluators");
    parser.add_list_option<Heuristic *>(
        "preferred",
        "use preferred operators of these heuristics", "[]");
    parser.add_option<bool>("reopen_closed",
                            "reopen closed nodes", "false");
    parser.add_option<int>(
        "boost",
        "boost value for alternation queues that are restricted "
        "to preferred operator nodes",
        OptionParser::to_str(DEFAULT_LAZY_BOOST));
    SearchEngine::add_options_to_parser(parser);
    Options opts = parser.parse();

    LazySearch *engine = 0;
    if (!parser.dry_run()) {
        vector<ScalarEvaluator *> evals =
            opts.get_list<ScalarEvaluator *>("evals");
        vector<Heuristic *> preferred_list =
            opts.get_list<Heuristic *>("preferred");
        OpenList<OpenListEntryLazy> *open;
        if ((evals.size() == 1) && preferred_list.empty()) {
            open = new StandardScalarOpenList<OpenListEntryLazy>(evals[0],
                                                                 false);
        } else {
            vector<OpenList<OpenListEntryLazy> *> inner_lists;
            for (int i = 0; i < evals.size(); i++) {
                inner_lists.push_back(
                    new StandardScalarOpenList<OpenListEntryLazy>(evals[i],
                                                                  false));
                if (!preferred_list.empty()) {
                    inner_lists.push_back(
                        new StandardScalarOpenList<OpenListEntryLazy>(evals[i],
                                                                      true));
                }
            }
            open = new AlternationOpenList<OpenListEntryLazy>(
                inner_lists, opts.get<int>("boost"));
        }
        opts.set("open", open);
        engine = new LazySearch(opts);
        engine->set_pref_operator_heuristics(preferred_list);
    }
    return engine;
}

static SearchEngine *_parse_weighted_astar(OptionParser &parser) {
    parser.document_synopsis(
        "(Weighted) A* search (lazy)",
        "Weighted A* is a special case of lazy best first search.");
    parser.document_note(
        "Open lists",
        "In the general case, it uses an alternation open list "
        "with one queue for each evaluator h that ranks the nodes "
        "by g + w * h. If preferred operator heuristics are used, "
        "it adds for each of the evaluators another such queue that "
        "only inserts nodes that are generated by preferred operators. "
        "In the special case with only one evaluator and no preferred "
        "operator heuristics, it uses a single queue that "
        "is ranked by g + w * h. ");
    parser.document_note("Equivalent statements using general lazy search",
        "\n```\n--heuristic h1=eval1\n"
        "--search lazy_wastar([h1, eval2], w=2, preferred=h1,\n"
        "                     bound=100, boost=500)\n```\n"
        "is equivalent to\n"
        "```\n--heuristic h1=eval1 --heuristic h2=eval2\n"
        "--search lazy(alt([single(sum([g(), weight(h1, 2)])),\n"
        "                   single(sum([g(), weight(h1, 2)]), pref_only=true),\n"
        "                   single(sum([g(), weight(h2, 2)])),\n"
        "                   single(sum([g(), weight(h2, 2)]), pref_only=true)],\n"
        "                  boost=500),\n"
        "              preferred=h1, reopen_closed=true, bound=100)\n```\n"
        "------------------------------------------------------------\n"
        "```\n--search lazy_wastar([eval1, eval2], w=2, bound=100)\n```\n"
        "is equivalent to\n"
        "```\n--search lazy(alt([single(sum([g(), weight(eval1, 2)])),\n"
        "                   single(sum([g(), weight(eval2, 2)]))],\n"
        "                  boost=1000),\n"
        "              reopen_closed=true, bound=100)\n```\n"
        "------------------------------------------------------------\n"
        "```\n--search lazy_wastar([eval1, eval2], bound=100, boost=0)\n```\n"
        "is equivalent to\n"
        "```\n--search lazy(alt([single(sum([g(), eval1])),\n"
        "                   single(sum([g(), eval2]))])\n"
        "              reopen_closed=true, bound=100)\n```\n"
        "------------------------------------------------------------\n"
        "```\n--search lazy_wastar(eval1, w=2)\n```\n"
        "is equivalent to\n"
        "```\n--search lazy(single(sum([g(), weight(eval1, 2)])), reopen_closed=true)\n```\n",
        true);

    parser.add_list_option<ScalarEvaluator *>("evals", "scalar evaluators");
    parser.add_list_option<Heuristic *>(
        "preferred",
        "use preferred operators of these heuristics", "[]");
    parser.add_option<bool>("reopen_closed", "reopen closed nodes", "true");
    parser.add_option<int>("boost",
                           "boost value for preferred operator open lists",
                           OptionParser::to_str(DEFAULT_LAZY_BOOST));
    parser.add_option<int>("w", "heuristic weight", "1");
    SearchEngine::add_options_to_parser(parser);
    Options opts = parser.parse();

    opts.verify_list_non_empty<ScalarEvaluator *>("evals");

    LazySearch *engine = 0;
    if (!parser.dry_run()) {
        vector<ScalarEvaluator *> evals = opts.get_list<ScalarEvaluator *>("evals");
        vector<Heuristic *> preferred_list =
            opts.get_list<Heuristic *>("preferred");
        vector<OpenList<OpenListEntryLazy> *> inner_lists;
        for (int i = 0; i < evals.size(); i++) {
            GEvaluator *g = new GEvaluator();
            vector<ScalarEvaluator *> sum_evals;
            sum_evals.push_back(g);
            if (opts.get<int>("w") == 1) {
                sum_evals.push_back(evals[i]);
            } else {
                WeightedEvaluator *w = new WeightedEvaluator(
                    evals[i],
                    opts.get<int>("w"));
                sum_evals.push_back(w);
            }
            SumEvaluator *f_eval = new SumEvaluator(sum_evals);

            inner_lists.push_back(
                new StandardScalarOpenList<OpenListEntryLazy>(f_eval, false));

            if (!preferred_list.empty()) {
                inner_lists.push_back(
                    new StandardScalarOpenList<OpenListEntryLazy>(f_eval,
                                                                  true));
            }
        }
        OpenList<OpenListEntryLazy> *open;
        if (inner_lists.size() == 1) {
            open = inner_lists[0];
        } else {
            open = new AlternationOpenList<OpenListEntryLazy>(
                inner_lists, opts.get<int>("boost"));
        }

        opts.set("open", open);

        engine = new LazySearch(opts);
        engine->set_pref_operator_heuristics(preferred_list);
    }
    return engine;
}

static SearchEngine *_parse_anytime_weighted_astar(OptionParser &parser) {
    parser.document_synopsis(
        "(Weighted) A* search (lazy)",
        "Weighted A* is a special case of lazy best first search.");
    parser.document_note(
        "Open lists",
        "In the general case, it uses an alternation open list "
        "with one queue for each evaluator h that ranks the nodes "
        "by g + w * h. If preferred operator heuristics are used, "
        "it adds for each of the evaluators another such queue that "
        "only inserts nodes that are generated by preferred operators. "
        "In the special case with only one evaluator and no preferred "
        "operator heuristics, it uses a single queue that "
        "is ranked by g + w * h. ");
    parser.document_note("Equivalent statements using general lazy search",
        "\n```\n--heuristic h1=eval1\n"
        "--search lazy_wastar([h1, eval2], w=2, preferred=h1,\n"
        "                     bound=100, boost=500)\n```\n"
        "is equivalent to\n"
        "```\n--heuristic h1=eval1 --heuristic h2=eval2\n"
        "--search lazy(alt([single(sum([g(), weight(h1, 2)])),\n"
        "                   single(sum([g(), weight(h1, 2)]), pref_only=true),\n"
        "                   single(sum([g(), weight(h2, 2)])),\n"
        "                   single(sum([g(), weight(h2, 2)]), pref_only=true)],\n"
        "                  boost=500),\n"
        "              preferred=h1, reopen_closed=true, bound=100)\n```\n"
        "------------------------------------------------------------\n"
        "```\n--search lazy_wastar([eval1, eval2], w=2, bound=100)\n```\n"
        "is equivalent to\n"
        "```\n--search lazy(alt([single(sum([g(), weight(eval1, 2)])),\n"
        "                   single(sum([g(), weight(eval2, 2)]))],\n"
        "                  boost=1000),\n"
        "              reopen_closed=true, bound=100)\n```\n"
        "------------------------------------------------------------\n"
        "```\n--search lazy_wastar([eval1, eval2], bound=100, boost=0)\n```\n"
        "is equivalent to\n"
        "```\n--search lazy(alt([single(sum([g(), eval1])),\n"
        "                   single(sum([g(), eval2]))])\n"
        "              reopen_closed=true, bound=100)\n```\n"
        "------------------------------------------------------------\n"
        "```\n--search lazy_wastar(eval1, w=2)\n```\n"
        "is equivalent to\n"
        "```\n--search lazy(single(sum([g(), weight(eval1, 2)])), reopen_closed=true)\n```\n",
        true);

    parser.add_list_option<ScalarEvaluator *>("evals", "scalar evaluators");
    parser.add_list_option<Heuristic *>(
        "preferred",
        "use preferred operators of these heuristics", "[]");
    parser.add_option<bool>("reopen_closed", "reopen closed nodes", "true");
    parser.add_option<int>("boost",
                           "boost value for preferred operator open lists",
                           OptionParser::to_str(DEFAULT_LAZY_BOOST));
    parser.add_option<int>("w", "heuristic weight", "1");
    parser.add_option<double>("delta", "PAC delta", "0");
    parser.add_option<double>("epsilon", "PAC epsilon", "0");
    parser.add_option<int>("rpac_lower_bound", "Ratio Based PAC Condition + LowerBound", "0");
    parser.add_option<int>("rpac_open_based", "Open Based PAC Condition", "0");
    SearchEngine::add_options_to_parser(parser);
    Options opts = parser.parse();

    opts.verify_list_non_empty<ScalarEvaluator *>("evals");

    LazySearch *engine = 0;


    if (!parser.dry_run()) {
        vector<ScalarEvaluator *> evals = opts.get_list<ScalarEvaluator *>("evals");
        vector<ScalarEvaluator *> evals_for_anytime = opts.get_list<ScalarEvaluator *>("evals");
        
        vector<Heuristic *> preferred_list =
            opts.get_list<Heuristic *>("preferred");

        vector<OpenList<OpenListEntryLazy> *> inner_lists;

        for (int i = 0; i < evals.size(); i++) {
            GEvaluator *g = new GEvaluator();
            GEvaluator *g_for_anytime = new GEvaluator();
            vector<ScalarEvaluator *> sum_evals;
            vector<ScalarEvaluator *> sum_evals_for_anytime;
            sum_evals.push_back(g);

            if (opts.get<int>("w") == 1) {
                sum_evals.push_back(evals[i]);
            } else {
                WeightedEvaluator *w = new WeightedEvaluator(
                    evals[i],
                    opts.get<int>("w"));
                sum_evals.push_back(w);
            }
            SumEvaluator *f_eval = new SumEvaluator(sum_evals);
            sum_evals_for_anytime.push_back(g_for_anytime);
            sum_evals_for_anytime.push_back(evals[i]);
            SumEvaluator *f_eval_for_anytime = new SumEvaluator(sum_evals_for_anytime);

            inner_lists.push_back(
                new StandardScalarOpenListForAnyTime<OpenListEntryLazy>(f_eval, f_eval_for_anytime, false));

            if (!preferred_list.empty()) {
                inner_lists.push_back(
                    new StandardScalarOpenListForAnyTime<OpenListEntryLazy>(f_eval, f_eval_for_anytime, true));
            }

        }


        OpenList<OpenListEntryLazy> *open;
       
        if (inner_lists.size() == 1) {
            open = inner_lists[0];
        } else {
            open = new AlternationOpenList<OpenListEntryLazy>(
                inner_lists, opts.get<int>("boost"));
        }

        
        opts.set("open", open);
        opts.setIsAnyTime(true); //TODO coding convention - add "is_any_time" as a description to the function

        engine = new LazySearch(opts);
        engine->set_pref_operator_heuristics(preferred_list);

        //read the PAC data
        engine->FillPACInfo();

        double pac_delta = opts.get<double>("delta");
        double pac_epsilon = opts.get<double>("epsilon");
        int    is_lower_bound = opts.get<int>("rpac_lower_bound");
        int    is_rpac_open_based = opts.get<int>("rpac_open_based");

        engine->InitPacVariables(pac_epsilon, pac_delta, is_lower_bound, is_rpac_open_based);
        
    }
    return engine;
}


void LazySearch::InitPacVariables(double epsilon, double delta, int is_lower_bound,int is_rpac_open_based)
{
    
    cout << "INFO: InitPacVariables" << std::endl;

     cout << "is_rpac_open_based = [" << is_rpac_open_based << "]" << endl;
     cout << "is_lower_bound = [" << is_lower_bound << "]" << endl;

     m_is_running_RPac_Lower_Bound  = (is_lower_bound == 0) ? false : true;
     m_is_running_open_based_pac    = (is_rpac_open_based == 0) ? false : true;
     m_max_f_min                    = 0;
     m_pac_epsilon                  = epsilon;
     // delta                       = 100 - (int)(delta * 100); // old version
     m_pac_delta                    = (int) (delta * 100);
     m_open_based_P_hat             = 0.0; //init P accumulator
     m_last_f_val                   = 0;

     cout << "m_is_running_open_based_pac = [" << m_is_running_open_based_pac << "]" << endl;
     cout << "m_is_running_RPac_Lower_Bound = [" << m_is_running_RPac_Lower_Bound << "]" << endl;
     

     bool found = false;
     std::map<float, float>::const_iterator iter = m_ratio_to_statistics_for_pac.begin();
     for (; iter != m_ratio_to_statistics_for_pac.end();++iter)
     {
        if (iter->second > m_pac_delta)
        {
            found = true;
            break;
        }
     }
     if (found)
        m_pac_ratio_h = (--iter)->first;
     else
        m_pac_ratio_h = 1000;

     cout << "PAC Variables:" << std::endl;
     cout << "pac_epsilon: " << m_pac_epsilon << std::endl;
     cout << "pac_ratio_h: " << m_pac_ratio_h <<  std::endl;
     cout << "pac_probability: " << m_pac_delta << std::endl;

}

/*
the ratio based pac condition is:
Pr(U < h*(S) x (1+epsilon) ) > 1 - delta
*/
bool LazySearch::is_Ratio_PAC_Condition_satisfied()
{
    cout << "INFO: is_Ratio_PAC_Condition_satisfied"<< std::endl;

    double U = current_g;
    double w = 1 + m_pac_epsilon;
    double left = U / (m_Initial_H * w);

    cout << "U / (m_Initial_H * w)  " << U <<"/"<< m_Initial_H<< "*"<< w << " = " << left << std::endl;
    cout << "m_pac_ratio_h      =   " << m_pac_ratio_h << std::endl;

    bool ret = (  left  <=  m_pac_ratio_h ) ;
    cout << "INFO: is_Ratio_PAC_Condition_satisfied? "<< ret << std::endl;

    return ret;

}

/*
  | max F_min       h_star(s)          U            |
Pr| ---------   <=  --------   <   ---------------- |
  |   h(s)            h(s)          h(s)(1+epsilon) |
*/
bool LazySearch::is_Ratio_PAC_Condition_Lower_Bound_satisfied(int f_min)
{
    // if f_val is lower than max(f_min) it cannot be max(f_min)
    // therfore - return false - RPAC+LB is not satisfied 
    if(f_min <= m_max_f_min)
        return false;
    else
        m_max_f_min = f_min;

    double U = current_g;
    double error = 1 + m_pac_epsilon;

    double right = U / (m_Initial_H * error);
    double left = m_max_f_min / m_Initial_H;

    cout << "U / (m_Initial_H * error) = " << U << "/(" << m_Initial_H << " * " << error << ")" << endl;
    cout << "m_max_f_min / m_Initial_H = " << f_min << "/" << m_Initial_H << endl;

    bool ret = left < right;
    return ret;
}


/*
----
\
 \                h*[   ]       1    [     U                ]
 /   Log(1 - Pr( ---| S | <  ------- |----------  - g_node  | ))  >= Log(1-delta)
/                 h [   ]     h_node [ 1+epsilon            ]
----
*/

bool LazySearch::is_Ratio_PAC_Condition_Open_Based_satisfied()
{
    //cout << "is_Ratio_PAC_Condition_Open_Based_satisfied" << endl;
    
    double transformedDelta = m_pac_delta / 100;
    double log_delta = log(1 - transformedDelta );

    // cout << "m_open_based_P_hat = [" << m_open_based_P_hat << "]" << endl;
    cout << "log_delta          = [" << log_delta << "]" << endl;
    cout << "m_pac_delta        = [" << m_pac_delta << "]" << endl;

    return m_open_based_P_hat >= log_delta;

}

void LazySearch::FillPACInfo()
{
    if (!m_is_anytime)
        return;
    ifstream file ( "PAC_Commulative_ratio.csv" ); 
    string ratio;
    string stat;
    while ( file.good() )
    {
        getline ( file, ratio, ',' ); 
        getline ( file, stat, '\n' ); 
        if (atof(ratio.c_str()) != 0)
            m_ratio_to_statistics_for_pac[atof(ratio.c_str())] = atof(stat.c_str());

    }
    /*for (std::map<float, float>::const_iterator iter = m_ratio_to_statistics_for_pac.begin(); iter != m_ratio_to_statistics_for_pac.end();iter++)
        cout << "map[" << iter->first << "] = " << iter->second << std::endl;*/
}

static Plugin<SearchEngine> _plugin("lazy", _parse);
static Plugin<SearchEngine> _plugin_greedy("lazy_greedy", _parse_greedy);
static Plugin<SearchEngine> _plugin_weighted_astar("lazy_wastar", _parse_weighted_astar);
static Plugin<SearchEngine> _plugin_anytime_weighted_astar("lazy_anytime_wastar", _parse_anytime_weighted_astar);
